import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.thorrent/?site=cGui&function=viewInfo)", True)

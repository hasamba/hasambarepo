import atexit

try:
    from firebase import *
except:
     from .firebase import *


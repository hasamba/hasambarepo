# EasyNews plugin package.
